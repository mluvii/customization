if (window.name !== 'mluvii-iframe') {
	document.body.innerHTML = '<div class="mluvii-fake-chat">' + document.body.innerHTML + '</div>';
}
